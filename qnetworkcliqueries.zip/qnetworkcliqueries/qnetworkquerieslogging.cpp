#include "qnetworkquerieslogging.h"

Q_LOGGING_CATEGORY(queries, "queries")
Q_LOGGING_CATEGORY(queriesthread, "queriesthread")
Q_LOGGING_CATEGORY(queriesthreadNeighbors, "queriesthread.neighbors")
Q_LOGGING_CATEGORY(mplstetunnels, "queries.mplstetunnels")
